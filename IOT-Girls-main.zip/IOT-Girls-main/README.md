# IOT-Girls
Mengenali dan menganalisis warna dari gambar atau video 
