1. Download file zip dan masukkan file kedalam XAMPP->htdocs
2. Buat database dengan nama drawing atau sesuai yang diinginkan dapat dilihat pada kode setup.sql
3. Copy url yang ada pada air_canvas_ml ke browser untuk melihat apakah dashboard berhasil dibuat atau tidak
4. Jika berhasil lakukan import library 
5. Sesuaikan password dan nama database(jika berubah) pada kode save_image dan fetch data
6. Jika semua sudah sesuai maka run kode dan akan muncul frame dan canvas dan kta dapat menggambar secara virtual
7. Kita dapat menyimpan gambar dengan memilih opsi save dan gambar akan tersimpan dalam database dan dapat kita lihat pada
    dashboard yang dapat diakses melalui link url tadi.
